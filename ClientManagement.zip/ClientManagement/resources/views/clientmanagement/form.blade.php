@extends('layouts.app')
@section('title', 'Client Creation')
@section('content') 
<section class="content-header">
  <h1>{!! $pagetitle !!}</h1>
</section>
<section class="content">
  <div class="box">
    <div class="box-body">
      {!! Form::open(array('url' => 'client-store', 'class' => 'form-horizontal', 'method' =>'post', 'id'=>'client_create')) !!}
      {!! Form::hidden('id',$id) !!}
      <input type='hidden'  name="txt_name" class="txt_name" id="txt_name" value="{{$id}}" />
      <div class="form-group">
        {!! Form::label('Client Name',null,array('class' => 'col-md-4 control-label')) !!}
        <div class="col-md-5 fg-float {{ $errors->has('client_name') ? ' has-error' : '' }}">
          {!! Form::text('clientname',old( 'client_name', $client['client_name'] ),array('class'=>'form-control','id'=> 'js- clientname','maxlength' => '50')) !!}  
          <span id="js-clientname" style="color:red">
          </div> 
        </div> 
        <div class="form-group">
          {!! Form::label('Company',null,array('class' => 'col-md-4 control-label')) !!}
          <div class="col-md-5 fg-float {{ $errors->has('email') ? ' has-error' : '' }}">
            {!! Form::select('company',[''=>'Please Select'] + $company_name,old('company_id', $client['company_id'] ),array('class'=>'form-control','id'=> 'js-company')) !!}                               
            <span style="color:red" id="js-company">
            </div>
          </div>
          <div class="form-group">
            {!! Form::label('Email',null,array('class' => 'col-md-4 control-label')) !!}
            <div class="col-md-5 fg-float {{ $errors->has('email') ? ' has-error' : '' }}">
              {!! Form::text('email',old('email', $client['email'] ),array('class'=>'form-control','id'=> 'js-email')) !!}                               
              <span style="color:red" id="js-email">
              </div>
            </div>
            <div class="form-group">
             {!! Form::label('Mobile Number',null,array('class' => 'col-md-4 control-label')) !!}
             <div class="col-md-5 fg-float {{ $errors->has('mobile_number') ? ' has-error' : '' }}">
               {!! Form::text('mobile_number',old( 'mobile_number', $client['mobile_number'] ),array('class'=>'form-control','id'=> 'js-mobile_no','maxlength'=>'10')) !!}                               
               <span id="js-mobile" style="color:red"></span>
             </div>
           </div>
           <br>
           <div class="col-md-12 text-center">
            <button type="submit" class="btn btn-primary" id="js-saveclient">Submit</button>
            <a href="{!! url('/client-list') !!}">  <span  class="btn btn-danger waves-effect">Cancel</span></a>
          </div>  
          {!! Form::close() !!} 
        </div>
      </div>
    </section>
<script src="http://code.jquery.com/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script>
 <script text="text/javascript" src="{{ asset('js/toastr.js') }}" ></script>
<script type="text/javascript">
    @if(\Session::has('error'))
      toastr.error("error","{{ Session::get('error') }}");
    @endif
    //$(document).ready(function(){

       $('#client_create').validate({
       // errorElement: 'span',
        rules:{
          clientname:{
            required:true,
          },
          company:{
            required:true,
          },
          email:{
            required:true,
          },
          mobile_number:{
            required:true,
            number:true,
          },
        },
        messages:{
          clientname:{
            required:'Please enter the Client Name',
          },
          company:{
            required:'Please Select Company',
          },
          email:{
            required:'Please enter Eamil address',
          },
          mobile_number:{
            required:'Please select the Mobile Number',
          },
        },
        submitHandler:function(form){
          $('#js-saveclient').text('Processing').attr('disabled',true);
          form.submit();
        }  
      });
   </script>
@endsection
