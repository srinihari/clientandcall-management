<div class="card">
Hi welcome to <?php echo e(isset($name) ? $name : "---"); ?>

</div>
