<?php $__env->startSection('title', 'Callog Creation'); ?>
<?php $__env->startSection('content'); ?> 
<section class="content-header">
  <h1><?php echo $pagetitle; ?></h1>
</section>
<section class="content">
  <div class="box">
    <div class="box-body">
      <?php echo Form::open(array('url' => 'callog-store', 'class' => 'form-horizontal', 'method' =>'post', 'id'=>'callog_create')); ?>

      <?php echo Form::hidden('id',$id); ?>

      <input type='hidden'  name="txt_name" class="txt_name" id="txt_name" value="<?php echo e($id); ?>" />
    </div>
    <div class="container">
      <div class='col-sm-6'>
        <div class="form-group">
          <?php echo Form::label('Client Name',null,array('class' => 'col-md-4 control-label')); ?>

          <?php echo Form::select('client_id',[''=>'Select'] + $client_details,old( 'client_id', $callog['client_id'] ),array('class'=>'form-control','id'=> 'js- clientname','maxlength' => '50')); ?>  
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class='col-sm-6'>
          <div class="form-group">
           <?php echo Form::label('From Date',null,array('class' => 'col-md-4 control-label')); ?>

           <div class='input-group date' id='from_date'>
            <?php echo Form::text('from_date',old('from_date', $callog['from_date'] ),array('class'=>'form-control','id'=>'from_date')); ?>  
            <span class="input-group-addon">
              <span class="glyphicon glyphicon-calendar"></span>
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class='col-sm-6'>
        <div class="form-group">
         <?php echo Form::label('To Date',null,array('class' => 'col-md-4 control-label')); ?>

         <div class='input-group date' id='to_date'>
          <?php echo Form::text('to_date',old('to_date', $callog['to_date'] ),array('class'=>'form-control','id'=>'to_date')); ?>  
          <span class="input-group-addon">
            <span class="glyphicon glyphicon-calendar"></span>
          </span>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="container">
  <div class='col-sm-6'>
    <div class="form-group">
      <?php echo Form::label('Call Notes',null,array('class' => 'col-md-4 control-label')); ?>

      <?php echo Form::text('call_notes',old( 'call_notes', $callog['call_notes'] ),array('class'=>'form-control','id'=> 'js- call_notes','maxlength' => '50')); ?>  
    </div>
  </div>
</div>
</div>
<div class="col-md-12 text-center">
  <button type="submit" class="btn btn-primary" id="js-savecallog">Submit</button>
  <a href="<?php echo url('/callog-list'); ?>">  <span  class="btn btn-danger waves-effect">Cancel</span></a>
</div>  
<?php echo Form::close(); ?> 
</div>
</div>
</section>
<script src="http://code.jquery.com/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.7.14/js/bootstrap-datetimepicker.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.7.14/css/bootstrap-datetimepicker.min.css">
<script text="text/javascript" src="<?php echo e(asset('js/toastr.js')); ?>" ></script>
 <script type="text/javascript">
  <?php if(\Session::has('error')): ?>
  toastr.error("error","<?php echo e(Session::get('error')); ?>");
  <?php endif; ?>
    $('#from_date,#to_date').datetimepicker({
                useCurrent: false,
                minDate: moment()
            });

  $('#from_date').datetimepicker().on('dp.change', function (e) {
                var incrementDay = moment(new Date(e.date));
                incrementDay.add(1, 'days');
                $('#to_date').data('DateTimePicker').minDate(incrementDay);
                $(this).data("DateTimePicker").hide();
            });

            $('#to_date').datetimepicker().on('dp.change', function (e) {
                var decrementDay = moment(new Date(e.date));
                decrementDay.subtract(1, 'days');
                $('#from_date').data('DateTimePicker').maxDate(decrementDay);
                 $(this).data("DateTimePicker").hide();
            });


 //  $('#from_date').datetimepicker({
 //   format: 'YYYY-MM-DD',
 //   minDate: 0,
 // });

 //  $('#to_date').datetimepicker({
 //   format: 'YYYY-MM-DD',
 //          });    //$(document).ready(function(){

   $('#callog_create').validate({
       // errorElement: 'span',
       rules:{
        client_id:{
          required:true,
        },
        from_date:{
          required:true,
        },
        to_date:{
          required:true,
        },
        call_notes:{
          required:true,
        },
      },
      messages:{
        client_id:{
          required:'Please enter the Client Name',
        },
        from_date:{
          required:'Please Select From Date',
        },
        email:{
          required:'Please Select To Date',
        },
        mobile_number:{
          required:'Please Enter Call Notes',
        },
      },
      submitHandler:function(form){
        $('#js-savecallog').text('Processing').attr('disabled',true);
        form.submit();
      }  
    });
  </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>