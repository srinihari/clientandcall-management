<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\ClientDetails;
use App\Model\ClientMaster;
use App\Model\CompanyMaster;
use Validator;
use Carbon\Carbon;
class ClientManagementController extends Controller
{
   protected $clientdetails;
    public function __construct(){
    	$this->middleware('auth');
    	$this->clientdetails=new ClientDetails;
    }

   public function clientIndex(){
   	try{
   		$this->data['clientlist']=$this->clientdetails->getClientList();
   		return view('clientmanagement.index',$this->data);
   	}catch(Exception $e){
   		return $e->getMessage();
   	}
   }
   public function ClientCreate($id=false){
   	try{
   		if($id){
   			$this->data['client']=ClientDetails::find($id);
   		}else{
   			$this->data['client']=$this->getTableColumns($this->clientdetails->getTable());
   		}
   		$this->data['pagetitle']=$id ? "Update Client Details" : "Create Client Details";
   		$this->data['id']=$id;
   		$this->data['company_name']=CompanyMaster::pluck('name','id')->all();
   		return view('clientmanagement.form',$this->data);
   	}catch(Exception $e){
   		return $e->getMessage();
   	}
   }

   public function ClientStore(Request $request){
   	try{
   		$rules=array(
   		'clientname'=>'required|unique:client_details,client_name,'.$request->id.',id,deleted_at,NULL',
   		'company' => 'required|unique:client_details,company_id,'.$request->id.',id,deleted_at,NULL',
   		'email'=>'required',
   		'mobile_number' => 'required|min:10|max:10|regex:/[0-9]/');

   		$validator=Validator::make($request->all(),$rules);
   		if($validator->fails()){
   			return back()->with('error',$validator->errors()->first());
   		}else{
   		$client=ClientDetails::findorNew($request->id);
   		$client->client_name=trim($request->clientname);
   		$client->company_id=$request->company;
   		$client->email=$request->email;
   		$client->mobile_number=$request->mobile_number;
   		$request->timestamps=$request->id  ? true : false;
   		$client->created_at=Carbon::now();
   		$client->updated_at=Carbon::now();
   		$client->save();
   		return redirect('/client-list')->with('success',$request->id ? "Client Updated Successfully" : "Client Created Successfully");
   		}
   	}catch(Exception $e){
   		return $e->getMessage();
   	}
   }
     
   public function clientDelete(Request $request){
      try{
         if($request->filled('id')){
            $user=ClientDetails::find($request->id);
            $user->where('id',$request->id)->update(['deleted_at'=>Carbon::now()]);
            return redirect('/client-list')->with('success','Client Deleted Successfully');
         }
      }catch(Exception $e){
         return $e->getMessage();
      }

   }
}
