<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\CalllogtDetails;
use App\Model\ClientMaster;
use App\Model\ClientDetails;
use Validator;
use Carbon\Carbon;
class CalllogController extends Controller
{
   protected $callogdetails;
    public function __construct(){
    	$this->middleware('auth');
    	$this->callogdetails=new CalllogtDetails;
    }

   public function callogIndex(){
   	try{
   		$this->data['calloglist']=$this->callogdetails->getCallog();
   		return view('calllog.index',$this->data);
   	}catch(Exception $e){
   		return $e->getMessage();
   	}
   }
   public function calllogCreate($id=false){
   	try{
   		if($id){
   			$this->data['callog']=CalllogtDetails::find($id);
   		}else{
   			$this->data['callog']=$this->getTableColumns($this->callogdetails->getTable());
   		}
   		$this->data['pagetitle']=$id ? "Update Callog Details" : "Create Callog Details";
         $this->data['client_details']=ClientDetails::whereNull('deleted_at')->pluck('client_name','id')->all();
   		$this->data['id']=$id;
   		return view('calllog.form',$this->data);
   	}catch(Exception $e){
   		return $e->getMessage();
   	}
   }

   public function callogStore(Request $request){
   	try{
   		$rules=array(
   		'client_id'=>'required|unique:callog_details,client_id,'.$request->id.',id,deleted_at,NULL',
   		'from_date' => 'required',
   		'to_date'=>'required',
   		'call_notes' => 'required');

   		$validator=Validator::make($request->all(),$rules);
   		if($validator->fails()){
   			return back()->with('error',$validator->errors()->first());
   		}else{
   		$callog=CalllogtDetails::findorNew($request->id);
   		$callog->client_id=$request->client_id;
   		$callog->from_date=$request->from_date;
   		$callog->to_date=$request->to_date;
   		$callog->call_notes=$request->call_notes;
   		$request->timestamps=$request->id  ? true : false;
   		$callog->created_at=Carbon::now();
   		$callog->updated_at=Carbon::now();
   		$callog->save();
   		return redirect('/callog-list')->with('success',$request->id ? "Callog Updated Successfully" : "Callog Created Successfully");
   		}
   	}catch(Exception $e){
   		return $e->getMessage();
   	}
   }

   public function callogDelete(Request $request){
      try{
         if($request->filled('id')){
            $user=CalllogtDetails::find($request->id);
            $user->where('id',$request->id)->update(['deleted_at'=>Carbon::now()]);
            return redirect('/callog-list')->with('success','Callog Deleted Successfully');
         }
      }catch(Exception $e){
         return $e->getMessage();
      }

   }
}
