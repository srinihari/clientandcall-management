<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CompanyMaster extends Model
{
      protected $table='company_master';

}
