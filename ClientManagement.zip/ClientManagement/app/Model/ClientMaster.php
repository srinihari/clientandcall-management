<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ClientMaster extends Model
{
        protected $table='client_master';

    

}
